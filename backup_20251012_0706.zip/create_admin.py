from app import app, db, User, bcrypt

# --- ここで管理者アカウント情報を設定 ---
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "password" # 必ず後で変更してください
# ------------------------------------

with app.app_context():
    # 既に同じ名前のユーザーが存在するか確認
    existing_user = User.query.filter_by(username=ADMIN_USERNAME).first()

    if existing_user:
        print(f"ユーザー名 '{ADMIN_USERNAME}' は既に存在します。")
    else:
        # パスワードをハッシュ化
        hashed_password = bcrypt.generate_password_hash(ADMIN_PASSWORD).decode('utf-8')
        
        # is_admin=True に設定して新しいユーザーを作成
        new_admin = User(
            username=ADMIN_USERNAME, 
            password=hashed_password, 
            is_admin=True
        )
        
        # データベースに保存
        db.session.add(new_admin)
        db.session.commit()
        print(f"管理者アカウント '{ADMIN_USERNAME}' を作成しました。")