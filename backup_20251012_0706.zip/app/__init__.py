# app/__init__.py
import os
import uuid
import datetime
import logging
import re
from functools import wraps
from logging.handlers import RotatingFileHandler
from urllib.parse import urlparse

from flask import (
    Flask, render_template, request, jsonify,
    redirect, url_for, flash, g
)
from flask_sqlalchemy import SQLAlchemy
from flask_login import (
    LoginManager, UserMixin, login_user, logout_user,
    login_required, current_user
)
from flask_bcrypt import Bcrypt
from dotenv import load_dotenv

# CSRF
from flask_wtf import CSRFProtect
from flask_wtf.csrf import generate_csrf, CSRFError

# レート制限
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

# セキュリティヘッダ
from flask_talisman import Talisman

# 逆プロキシ
from werkzeug.middleware.proxy_fix import ProxyFix

# 外部API
import google.generativeai as genai
from googleapiclient.discovery import build


# =========================
# アプリ初期化 & 設定
# =========================
load_dotenv()


def create_app() -> Flask:
    app = Flask(
    __name__,
    instance_relative_config=True,
    template_folder="../templates",
    static_folder="../static",   # ← ここを必ずこの指定に
)

    # 逆プロキシ補正（Host も反映）
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

    # フォルダ確保
    os.makedirs(app.instance_path, exist_ok=True)
    os.makedirs(os.path.join(app.instance_path, "logs"), exist_ok=True)

    # セッション/Cookie（Codespaces 等のHTTPSプロキシ向け）
    app.config.update(
        SECRET_KEY=os.environ.get("SECRET_KEY") or os.urandom(24),

        SESSION_COOKIE_HTTPONLY=True,
        REMEMBER_COOKIE_HTTPONLY=True,

        SESSION_COOKIE_SAMESITE="None",
        REMEMBER_COOKIE_SAMESITE="None",
        SESSION_COOKIE_SECURE=True,
        REMEMBER_COOKIE_SECURE=True,

        SQLALCHEMY_TRACK_MODIFICATIONS=False,

        # 開発時はReferer厳格チェックを無効化（トークン検証は有効）
        WTF_CSRF_CHECK_REFERER=False,
    )

    # SQLite（絶対パス）
    db_path = os.path.join(app.instance_path, "database.db")
    app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{db_path}"

    return app


app = create_app()

# --- セキュリティヘッダ（CSP等） ---
csp = {
    'default-src': ["'self'"],
    'script-src': ["'self'", "https://cdn.jsdelivr.net"],
    'style-src': ["'self'", "https://cdn.jsdelivr.net", "'unsafe-inline'"],
    'font-src': ["'self'", "https://cdn.jsdelivr.net", "data:"],
    'img-src': ["'self'", "data:"],
}
talisman = Talisman(
    app,
    content_security_policy=csp,
    frame_options="DENY",
    referrer_policy="no-referrer",
    force_https=False,  # 本番は True
    session_cookie_secure=True,
)

db = SQLAlchemy(app)
bcrypt = Bcrypt(app)

# Login
login_manager = LoginManager(app)
login_manager.login_view = "login"

# CSRF
csrf = CSRFProtect(app)

@app.context_processor
def inject_csrf_token():
    return dict(csrf_token=generate_csrf)

@app.after_request
def set_csrf_cookie(resp):
    try:
        token = generate_csrf()
        resp.set_cookie("csrf_token", token, samesite="None", secure=True, httponly=False)
    except Exception:
        pass
    return resp

# Limiter
storage_uri = os.environ.get("REDIS_URL", "memory://")
limiter = Limiter(
    key_func=get_remote_address,
    app=app,
    storage_uri=storage_uri,
    default_limits=["200 per hour"],
)

# =========================
# ログ設定
# =========================
LOG_DIR = os.path.join(app.instance_path, "logs")
APP_LOG = os.path.join(LOG_DIR, "app.log")
ACCESS_LOG = os.path.join(LOG_DIR, "access.log")

app_logger = logging.getLogger("app")
app_logger.setLevel(logging.INFO)
if not app_logger.handlers:
    fh = RotatingFileHandler(APP_LOG, maxBytes=5 * 1024 * 1024, backupCount=5, encoding="utf-8")
    fh.setFormatter(logging.Formatter(
        "%(asctime)s | %(levelname)s | req_id=%(request_id)s | user=%(user)s | ip=%(ip)s | %(message)s"
    ))
    app_logger.addHandler(fh)

access_logger = logging.getLogger("access")
access_logger.setLevel(logging.INFO)
if not access_logger.handlers:
    af = RotatingFileHandler(ACCESS_LOG, maxBytes=10 * 1024 * 1024, backupCount=5, encoding="utf-8")
    af.setFormatter(logging.Formatter("%(asctime)s | %(message)s"))
    access_logger.addHandler(af)

logging.getLogger("werkzeug").setLevel(logging.INFO)

@app.before_request
def _before():
    g.request_id = uuid.uuid4().hex[:12]
    g.started_at = datetime.datetime.utcnow()
    g.ip = request.headers.get("X-Forwarded-For", request.remote_addr or "-")
    g.user = "-"
    if current_user.is_authenticated:
        g.user = f"{current_user.id}:{current_user.username}"

@app.after_request
def _after(resp):
    elapsed_ms = -1
    try:
        elapsed_ms = int((datetime.datetime.utcnow() - g.started_at).total_seconds() * 1000)
    except Exception:
        pass
    line = (
        f'req_id={getattr(g, "request_id", "-")} '
        f'ip={getattr(g, "ip", "-")} '
        f'user={getattr(g, "user", "-")} '
        f'method={request.method} path="{request.full_path}" '
        f'status={resp.status_code} bytes={resp.calculate_content_length() or 0} '
        f'{elapsed_ms}ms'
    )
    access_logger.info(line)
    return resp

def log_info(msg):
    app_logger.info(msg, extra={"request_id": getattr(g,"request_id","-"), "user": getattr(g,"user","-"), "ip": getattr(g,"ip","-")})
def log_warn(msg):
    app_logger.warning(msg, extra={"request_id": getattr(g,"request_id","-"), "user": getattr(g,"user","-"), "ip": getattr(g,"ip","-")})
def log_error(msg):
    app_logger.error(msg, extra={"request_id": getattr(g,"request_id","-"), "user": getattr(g,"user","-"), "ip": getattr(g,"ip","-")})

# =========================
# モデル
# =========================
class Conversation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False, default="新しいチャット")
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    messages = db.relationship('Message', backref='conversation', lazy=True, cascade="all, delete-orphan")
    is_pinned = db.Column(db.Boolean, nullable=False, default=False)

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    is_admin = db.Column(db.Boolean, nullable=False, default=False)
    conversations = db.relationship('Conversation', backref='user', lazy=True, cascade="all, delete-orphan")

class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    sender = db.Column(db.String(10), nullable=False)  # 'user' or 'model'
    conversation_id = db.Column(db.Integer, db.ForeignKey('conversation.id'), nullable=False)

class Announcement(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    message = db.Column(db.Text, nullable=False)
    is_active = db.Column(db.Boolean, nullable=False, default=False)
    timestamp = db.Column(db.DateTime, default=datetime.datetime.utcnow)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def admin_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash("このページにアクセスするには管理者権限が必要です。", 'warning')
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return wrapped

from flask_login import current_user as _cu
def user_or_ip():
    try:
        if _cu.is_authenticated:
            return f"user:{_cu.id}"
    except Exception:
        pass
    return get_remote_address()

# =========================
# 外部API（Gemini / Google CSE）
# =========================
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
if GEMINI_API_KEY:
    try:
        genai.configure(api_key=GEMINI_API_KEY)
    except Exception as e:
        log_warn(f"Gemini init failed: {e}")
else:
    log_warn("GEMINI_API_KEY not set.")

GOOGLE_API_KEY = os.environ.get("GOOGLE_API_KEY")
SEARCH_ENGINE_ID = os.environ.get("SEARCH_ENGINE_ID")

def _clean_text(s: str) -> str:
    s = s or ""
    s = re.sub(r"\s+", " ", s)
    return s.strip()

def _dedupe_by_link(items):
    seen = set()
    out = []
    for it in items:
        link = it.get("url")
        if not link or link in seen:
            continue
        seen.add(link)
        out.append(it)
    return out

def _domain(url: str) -> str:
    try:
        return urlparse(url).netloc.lower()
    except Exception:
        return ""

def perform_web_search(query: str, max_items: int = 5) -> list[dict]:
    """
    Google CSE を呼び出し、 title/url/snippet を持つ dict のリストを返す。
    失敗時は空配列。モデルへの入力は別途 format する。
    """
    if not GOOGLE_API_KEY or not SEARCH_ENGINE_ID:
        return []
    try:
        service = build("customsearch", "v1", developerKey=GOOGLE_API_KEY)
        res = service.cse().list(q=query, cx=SEARCH_ENGINE_ID, num=10).execute()
        items = []
        for it in res.get("items", []):
            title = _clean_text(it.get("title", ""))
            url = it.get("link", "")
            snippet = _clean_text(it.get("snippet", ""))
            if not url:
                continue
            items.append({"title": title, "url": url, "snippet": snippet, "domain": _domain(url)})
        # ドメイン重複をほどほどに抑える
        picked = []
        seen_domains = set()
        for it in _dedupe_by_link(items):
            if it["domain"] in seen_domains:
                continue
            seen_domains.add(it["domain"])
            picked.append({k: it[k] for k in ("title", "url", "snippet")})
            if len(picked) >= max_items:
                break
        return picked
    except Exception as e:
        log_error(f"WebSearch error: {e}")
        return []

# =========================
# 健康診断
# =========================
@app.route("/healthz")
@limiter.exempt
def healthz():
    return jsonify(status="ok", time=datetime.datetime.utcnow().isoformat()), 200

# =========================
# ルーティング
# =========================
@app.route("/setup/initial-admin", methods=['GET', 'POST'])
def initial_admin_setup():
    if User.query.filter_by(is_admin=True).first():
        flash("管理者アカウントは既に設定済みです。", 'info')
        return redirect(url_for('admin_login'))

    if request.method == 'POST':
        username = request.form.get('username','').strip()
        password = request.form.get('password','')
        if not username or not password:
            flash("ユーザー名とパスワードは必須です。", "warning")
            return render_template('initial_admin.html')

        hashed = bcrypt.generate_password_hash(password).decode('utf-8')
        new_admin = User(username=username, password=hashed, is_admin=True)
        db.session.add(new_admin)
        db.session.commit()
        log_info(f"Initial admin created: {username}")
        flash("管理者アカウントが作成されました。ログインしてください。", "success")
        return redirect(url_for('admin_login'))

    return render_template("initial_admin.html")

@app.route("/")
@login_required
def home():
    if current_user.is_admin:
        return redirect(url_for('admin_dashboard'))
    latest = Conversation.query.filter_by(user_id=current_user.id).order_by(Conversation.id.desc()).first()
    if not latest:
        new_convo = Conversation(user_id=current_user.id)
        db.session.add(new_convo)
        db.session.commit()
        return redirect(url_for('chat_page', conversation_id=new_convo.id))
    return redirect(url_for('chat_page', conversation_id=latest.id))

@app.route("/conversation/<int:conversation_id>")
@login_required
def chat_page(conversation_id):
    # 全ユーザーの会話を取得（ピン留め優先 + 新しい順）
    all_conversations = Conversation.query.filter_by(user_id=current_user.id)\
        .order_by(Conversation.is_pinned.desc(), Conversation.id.desc()).all()

    # 該当の会話を取得
    current_convo = Conversation.query.get_or_404(conversation_id)

    # 権限チェック（管理者以外は他人の会話にアクセスできない）
    if not current_user.is_admin and current_convo.user_id != current_user.id:
        return "Unauthorized", 403

    # アクティブなお知らせ（ある場合のみ表示）
    active_announcement = Announcement.query.filter_by(is_active=True).first()

    # index.html に渡す変数
    return render_template(
        "index.html",
        conversations=all_conversations,
        current_convo=current_convo,   # ← ここ重要！
        announcement=active_announcement
    )

@app.route("/register", methods=["GET", "POST"])
def register():
    if not User.query.filter_by(is_admin=True).first():
        flash("システムセットアップが完了していません。管理者に連絡してください。", 'warning')
        return redirect(url_for('login'))

    if request.method == "POST":
        username = request.form.get("username","").strip()
        password = request.form.get("password","")
        if not username or not password:
            return render_template("register.html", error="ユーザー名とパスワードは必須です。")
        if User.query.filter_by(username=username).first():
            return render_template("register.html", error="このユーザー名は既に使用されています。")

        hashed = bcrypt.generate_password_hash(password).decode('utf-8')
        user = User(username=username, password=hashed)
        db.session.add(user)
        db.session.commit()

        new_convo = Conversation(user_id=user.id)
        db.session.add(new_convo)
        db.session.commit()

        login_user(user)
        log_info(f"User registered: {username}")
        return redirect(url_for('chat_page', conversation_id=new_convo.id))

    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
@limiter.limit("10 per minute; 40 per hour", methods=["POST"])
def login():
    if not User.query.filter_by(is_admin=True).first():
        flash("ようこそ！最初の管理者アカウントをセットアップしてください。", "info")
        return redirect(url_for('initial_admin_setup'))

    if request.method == "POST":
        username = request.form.get("username","")
        password = request.form.get("password","")
        user = User.query.filter_by(username=username).first()
        if user and bcrypt.check_password_hash(user.password, password):
            login_user(user)
            log_info(f"Login success: {username}")
            return redirect(url_for("home"))
        log_warn(f"Login failed: {username}")
        return render_template("login.html", error="ユーザー名またはパスワードが正しくありません。")

    return render_template("login.html")

@app.route("/logout")
@login_required
def logout():
    log_info("Logout")
    logout_user()
    return redirect(url_for("login"))

@app.route("/conversation/<int:conversation_id>/pin", methods=["POST"])
@login_required
@limiter.limit("30 per minute", key_func=user_or_ip)
def toggle_pin(conversation_id):
    convo = Conversation.query.get_or_404(conversation_id)
    if convo.user_id != current_user.id:
        return jsonify({"error": "Unauthorized"}), 403
    convo.is_pinned = not convo.is_pinned
    db.session.commit()
    return jsonify({"success": True, "is_pinned": convo.is_pinned})

@app.route("/new_chat", methods=["POST"])
@login_required
@limiter.limit("10 per minute", key_func=user_or_ip)
def new_chat():
    new_convo = Conversation(user_id=current_user.id, title="新しいチャット")
    db.session.add(new_convo)
    db.session.commit()
    return jsonify({"conversation_id": new_convo.id})

@app.route("/conversation/<int:conversation_id>/messages")
@login_required
@limiter.limit("120 per minute", key_func=user_or_ip)
def get_messages(conversation_id):
    convo = Conversation.query.get_or_404(conversation_id)
    if (not current_user.is_admin) and (convo.user_id != current_user.id):
        return jsonify({"error": "Unauthorized"}), 403
    messages = [{"sender": m.sender, "content": m.content} for m in convo.messages]
    return jsonify(messages)

@app.route("/conversation/<int:conversation_id>", methods=["DELETE"])
@login_required
@limiter.limit("5 per minute", key_func=user_or_ip)
def delete_conversation(conversation_id):
    convo = Conversation.query.get_or_404(conversation_id)
    if (not current_user.is_admin) and (convo.user_id != current_user.id):
        return jsonify(success=False, error="Unauthorized"), 403
    db.session.delete(convo)
    db.session.commit()
    return jsonify(success=True)

# 許可するモデル（任意の安全策）
ALLOWED_MODELS = {
    "models/gemini-flash-latest",
    "models/gemini-pro-latest",
}

@app.route("/summarize_title", methods=["POST"])
@login_required
@limiter.limit("20 per minute; 200 per hour", key_func=user_or_ip)
def summarize_title():
    data = request.get_json(silent=True) or {}
    conversation_id = data.get('conversation_id')
    first_message = data.get('first_message')
    if not conversation_id or not first_message:
        return jsonify({"error": "Missing data"}), 400
    try:
        model = genai.GenerativeModel('models/gemini-flash-latest')
        prompt = (
            "以下の文章を、チャットのタイトルとして10文字以内の非常に短い日本語の要約にしてください:\n\n"
            f"{first_message}"
        )
        response = model.generate_content(prompt)
        new_title = (response.text or "").strip().replace("「","").replace("」","")
        convo = Conversation.query.get(conversation_id)
        if convo and convo.user_id == current_user.id:
            convo.title = new_title or "新しいチャット"
            db.session.commit()
            return jsonify({"new_title": new_title})
        return jsonify({"error": "Conversation not found or unauthorized"}), 404
    except Exception as e:
        log_error(f"Summarize error: {e}")
        return jsonify({"error": "要約でエラーが発生しました。"}), 500

@app.route("/chat", methods=["POST"])
@login_required
@limiter.limit("30 per minute; 300 per hour", key_func=user_or_ip)
def chat():
    data = request.get_json(silent=True) or {}
    user_message = (data.get("message") or "").strip()
    model_name = data.get("model", "models/gemini-flash-latest")
    web_search = bool(data.get("web_search", False))
    conversation_id = data.get("conversation_id")
    if not conversation_id:
        return jsonify({"error": "Conversation ID is required"}), 400
    if not user_message:
        return jsonify({"error": "メッセージが空です。"}), 400

    # モデル名ホワイトリスト（任意）
    if model_name not in ALLOWED_MODELS:
        model_name = "models/gemini-flash-latest"

    convo = Conversation.query.get_or_404(conversation_id)
    if (not current_user.is_admin) and (convo.user_id != current_user.id):
        return jsonify({"error": "Unauthorized"}), 403

    db.session.add(Message(content=user_message, sender='user', conversation_id=conversation_id))

    try:
        model = genai.GenerativeModel(model_name)

        sources = []
        if web_search:
            sources = perform_web_search(user_message, max_items=5)

        if sources:
            # [1], [2] 参照形式で Gemini に回答させる
            numbered = "\n".join(
                f"[{i+1}] {s['title']} — {s['url']}\n{('要約: ' + s['snippet']) if s.get('snippet') else ''}".strip()
                for i, s in enumerate(sources)
            )
            sys_prompt = (
                "あなたは丁寧な日本語で回答する賢いアシスタントです。"
                "与えられたウェブ検索の要約を根拠に、結論を短く、必要なら補足を簡潔に述べてください。"
                "参照は [番号] で付けてください（例: [1][3]）。出典が曖昧な場合は『不確実』と明記。"
            )
            prompt = (
                f"{sys_prompt}\n\n"
                f"▼質問\n{user_message}\n\n"
                f"▼検索要約\n{numbered}\n\n"
                f"▼要件\n- まず1-2文で結論。\n- 次に必要な補足を箇条書きで（最大3つ）。\n- 文末に関連する出典の [番号] を付与。"
            )
            response = model.generate_content(prompt)
        else:
            # 検索なし：通常応答
            response = model.generate_content(user_message)

        ai_reply = (response.text or "").strip()

        db.session.add(Message(content=ai_reply, sender='model', conversation_id=conversation_id))
        db.session.commit()

        # ここが新仕様：sources をフロントへ返す
        return jsonify({"reply": ai_reply, "sources": sources})

    except Exception as e:
        db.session.rollback()
        log_error(f"Chat error: {e}")
        return jsonify({"error": "AI応答の生成に失敗しました。"}), 500

@app.route("/admin/login", methods=["GET", "POST"])
@limiter.limit("6 per minute; 20 per hour", methods=["POST"])
def admin_login():
    if request.method == "POST":
        username = request.form.get("username","")
        password = request.form.get("password","")
        user = User.query.filter_by(username=username).first()
        if user and user.is_admin and bcrypt.check_password_hash(user.password, password):
            login_user(user)
            log_info(f"Admin login success: {username}")
            return redirect(url_for('admin_dashboard'))
        flash("管理者アカウント情報が正しくありません。", 'danger')
        log_warn(f"Admin login failed: {username}")
        return render_template("admin_login.html")
    return render_template("admin_login.html")

@app.route("/admin/dashboard")
@login_required
@admin_required
def admin_dashboard():
    total_users = User.query.count()
    total_conversations = Conversation.query.count()
    total_messages = Message.query.count()
    users = User.query.all()
    current_announcement = Announcement.query.order_by(Announcement.id.desc()).first()
    return render_template(
        "admin_dashboard.html",
        users=users,
        total_users=total_users,
        total_conversations=total_conversations,
        total_messages=total_messages,
        announcement=current_announcement
    )

@app.route('/admin/announcement', methods=['POST'])
@login_required
@admin_required
def manage_announcement():
    message = request.form.get('message','')
    action = request.form.get('action','')

    Announcement.query.update({Announcement.is_active: False})

    if action == 'update' and message:
        new_anno = Announcement(message=message, is_active=True)
        db.session.add(new_anno)
        flash('新しいお知らせを公開しました。', 'success')
        log_info("Announcement updated & published")
    elif action == 'deactivate':
        flash('お知らせを非公開にしました。', 'info')
        log_info("Announcement deactivated")

    db.session.commit()
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/delete_user/<int:user_id>', methods=['POST'])
@login_required
@admin_required
@limiter.limit("10 per minute", key_func=user_or_ip)
def delete_user(user_id):
    if user_id == current_user.id:
        flash('自分自身のアカウントは削除できません。', 'danger')
        return redirect(url_for('admin_dashboard'))
    target = User.query.get_or_404(user_id)
    db.session.delete(target)
    db.session.commit()
    log_warn(f"User deleted: {target.username} ({target.id}) by admin")
    flash(f'ユーザー "{target.username}" を削除しました。', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/view_user/<int:user_id>')
@login_required
@admin_required
def view_user(user_id):
    user = User.query.get_or_404(user_id)
    conversations = Conversation.query.filter_by(
        user_id=user.id
    ).order_by(Conversation.is_pinned.desc(), Conversation.id.desc()).all()
    return render_template('admin_user_view.html', target_user=user, conversations=conversations)

# =========================
# エラーハンドラ
# =========================
def _wants_json():
    return request.accept_mimetypes.best == "application/json" or request.is_json

@app.errorhandler(400)
def bad_request(e):
    if _wants_json():
        return jsonify(error="bad_request"), 400
    return render_template("error.html", code=400, message="不正なリクエストです。"), 400

@app.errorhandler(403)
def forbidden(e):
    if _wants_json():
        return jsonify(error="forbidden"), 403
    return render_template("error.html", code=403, message="アクセス権限がありません。"), 403

@app.errorhandler(404)
def not_found(e):
    if _wants_json():
        return jsonify(error="not_found"), 404
    return render_template("error.html", code=404, message="ページが見つかりません。"), 404

@app.errorhandler(429)
def ratelimit_handler(e):
    if _wants_json():
        return jsonify(error="rate_limited", detail=str(e.description)), 429
    return render_template("error.html", code=429, message="短時間にリクエストが集中しています。時間をおいてお試しください。"), 429

@app.errorhandler(500)
def internal_error(e):
    log_error(f"Unhandled error: {e}")
    if _wants_json():
        return jsonify(error="internal_server_error"), 500
    return render_template("error.html", code=500, message="サーバー内部でエラーが発生しました。"), 500

@app.errorhandler(CSRFError)
def handle_csrf_error(e):
    log_warn(f"CSRF failed: {e.description}")
    if _wants_json():
        return jsonify(error="csrf_failed", detail=e.description), 400
    return render_template("error.html", code=400, message=f"CSRFエラー: {e.description}"), 400

# =========================
# DB 初期化
# =========================
with app.app_context():
    db.create_all()


