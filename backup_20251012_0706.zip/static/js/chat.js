// static/js/chat.js

// サーバーから渡されたIDを tojson で安全に受け取る（テンプレート側で埋め込まれる）
/* global CURRENT_CONVERSATION_ID */

let chatMessages, messageInput, webSearchToggle, currentModel, headerTitle;

// CSRF
function getCsrf() {
  const meta = document.querySelector('meta[name="csrf-token"]');
  return meta ? meta.content : '';
}

async function api(path, options = {}) {
  const headers = {
    'Content-Type': 'application/json',
    'X-CSRFToken': getCsrf(),
    ...(options.headers || {}),
  };
  const res = await fetch(path, { ...options, headers });
  let data = {};
  try { data = await res.json(); } catch (_) {}
  if (!res.ok) {
    if (res.status === 429) {
      const ra = res.headers.get('Retry-After');
      const msg = ra ? `短時間にリクエストが集中しています。${ra} 秒後に再試行してください。` : `短時間にリクエストが集中しています。しばらくしてから再試行してください。`;
      throw new Error(msg);
    }
    throw new Error(data && data.error ? data.error : `HTTP ${res.status}`);
  }
  return data;
}

function scrollToBottom(force = false) {
  const nearBottom = chatMessages.scrollHeight - chatMessages.scrollTop - chatMessages.clientHeight < 40;
  if (force || nearBottom) chatMessages.scrollTop = chatMessages.scrollHeight;
}

function addMessageToUI(text, sender, sources) {
  const messageRow = document.createElement('div');
  messageRow.className = `message-row ${sender === 'user' ? 'user-message' : 'model-message'}`;

  const messageContent = document.createElement('div');
  messageContent.className = 'message-content';
  messageContent.textContent = text; // XSS対策

  // 出典の表示（安全に createElement で作る）
  if (sender !== 'user' && Array.isArray(sources) && sources.length) {
    const srcWrap = document.createElement('div');
    srcWrap.className = 'source-list';
    const ul = document.createElement('ul');
    ul.style.paddingLeft = '1.1rem';
    ul.style.marginBottom = '0';
    sources.forEach((s, idx) => {
      const li = document.createElement('li');
      const a = document.createElement('a');
      a.href = s.url;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      a.textContent = `[${idx + 1}] ${s.title || s.url}`;
      li.appendChild(a);
      if (s.snippet) {
        const small = document.createElement('div');
        small.textContent = s.snippet;
        small.style.opacity = '0.8';
        li.appendChild(small);
      }
      ul.appendChild(li);
    });
    srcWrap.appendChild(ul);
    messageContent.appendChild(srcWrap);
  }

  messageRow.appendChild(messageContent);
  chatMessages.appendChild(messageRow);
  scrollToBottom();
}

async function loadMessages() {
  if (!CURRENT_CONVERSATION_ID) {
    const container = document.getElementById('chat-messages');
    if (container) {
      container.innerHTML = '<div class="welcome-message"><p>エラー: 会話IDが見つかりません。</p></div>';
    }
    return;
  }
  const res = await fetch(`/conversation/${CURRENT_CONVERSATION_ID}/messages`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const messages = await res.json();
  const cm = document.getElementById('chat-messages');
  cm.innerHTML = '';
  if (!messages.length) {
    cm.innerHTML = '<div class="welcome-message"><p>こんにちは、何をお手伝いできますか？</p></div>';
  } else {
    const frag = document.createDocumentFragment();
    messages.forEach((m) => {
      const row = document.createElement('div');
      row.className = `message-row ${m.sender === 'user' ? 'user-message' : 'model-message'}`;
      const content = document.createElement('div');
      content.className = 'message-content';
      content.textContent = m.content;
      row.appendChild(content);
      frag.appendChild(row);
    });
    cm.appendChild(frag);
  }
  scrollToBottom(true);
}

async function summarizeAndUpdateTitle(firstMessage) {
  try {
    const data = await api('/summarize_title', {
      method: 'POST',
      body: JSON.stringify({ conversation_id: CURRENT_CONVERSATION_ID, first_message: firstMessage }),
    });
    if (data.new_title) {
      headerTitle.textContent = data.new_title;
      const sidebarItem = document.querySelector(`.convo-item[data-id="${CURRENT_CONVERSATION_ID}"] .convo-title`);
      if (sidebarItem) sidebarItem.textContent = data.new_title;
    }
  } catch (e) {
    console.error('Title summarization failed:', e);
  }
}

async function startNewChat() {
  try {
    const data = await api('/new_chat', { method: 'POST' });
    window.location.href = `/conversation/${data.conversation_id}`;
  } catch (e) {
    alert('新規チャットの作成に失敗しました。');
  }
}

async function deleteConversation(convoId) {
  if (!confirm('この会話を本当に削除しますか？')) return;
  try {
    await api(`/conversation/${convoId}`, { method: 'DELETE' });
    if (String(convoId) === String(CURRENT_CONVERSATION_ID)) {
      window.location.href = '/';
    } else {
      const el = document.querySelector(`.convo-item[data-id="${convoId}"]`);
      if (el) el.remove();
    }
  } catch (e) {
    alert('削除に失敗しました。');
  }
}

function sortConversations() {
  const list = document.getElementById('conversation-list');
  const items = Array.from(list.querySelectorAll('.convo-item'));
  items.sort((a, b) => {
    const aPinned = a.querySelector('.pin-btn')?.classList.contains('pinned');
    const bPinned = b.querySelector('.pin-btn')?.classList.contains('pinned');
    if (aPinned !== bPinned) return aPinned ? -1 : 1;
    const aTitle = a.querySelector('.convo-title')?.textContent || '';
    const bTitle = b.querySelector('.convo-title')?.textContent || '';
    return aTitle.localeCompare(bTitle, 'ja');
  });
  items.forEach((el) => list.appendChild(el));
}

async function togglePin(convoId) {
  try {
    const data = await api(`/conversation/${convoId}/pin`, { method: 'POST' });
    const item = document.querySelector(`.convo-item[data-id="${convoId}"]`);
    if (!item) return;
    const pinButton = item.querySelector('.pin-btn');
    const titleSpan = item.querySelector('.convo-title');
    if (data.success) {
      pinButton.classList.toggle('pinned', data.is_pinned);
      const existingPinIcon = item.querySelector('.bi-pin-angle-fill');
      if (data.is_pinned && !existingPinIcon) {
        const pinIcon = document.createElement('i');
        pinIcon.className = 'bi bi-pin-angle-fill text-primary me-2';
        pinIcon.setAttribute('aria-hidden', 'true');
        item.insertBefore(pinIcon, titleSpan);
      } else if (!data.is_pinned && existingPinIcon) {
        existingPinIcon.remove();
      }
      sortConversations();
    }
  } catch (e) {
    alert('ピン留めの変更に失敗しました。');
  }
}

async function sendMessage() {
  const userMessage = messageInput.value.trim();
  if (!userMessage) return;
  const sendBtn = document.getElementById('send-button');

  const isFirstMessage = !document.querySelector('.message-row');
  if (document.querySelector('.welcome-message')) {
    chatMessages.innerHTML = '';
  }

  addMessageToUI(userMessage, 'user');
  messageInput.value = '';
  messageInput.style.height = 'auto';

  if (isFirstMessage) summarizeAndUpdateTitle(userMessage);

  sendBtn.disabled = true;
  const typingEl = document.createElement('div');
  typingEl.className = 'message-row model-message';
  const typingBubble = document.createElement('div');
  typingBubble.className = 'message-content';
  typingBubble.textContent = '返信を作成中…';
  typingEl.appendChild(typingBubble);
  chatMessages.appendChild(typingEl);
  scrollToBottom();

  try {
    const data = await api('/chat', {
      method: 'POST',
      body: JSON.stringify({
        message: userMessage,
        model: currentModel,
        web_search: webSearchToggle.checked,
        conversation_id: CURRENT_CONVERSATION_ID,
      }),
    });
    typingEl.remove();
    addMessageToUI(data.reply, 'model', data.sources);
  } catch (e) {
    typingEl.remove();
    addMessageToUI('エラー: ' + e.message, 'model');
  } finally {
    sendBtn.disabled = false;
    messageInput.focus();
  }
}

// 初期化
document.addEventListener('DOMContentLoaded', () => {
  chatMessages = document.getElementById('chat-messages');
  messageInput = document.getElementById('message-input');
  webSearchToggle = document.getElementById('web-search-toggle');
  headerTitle = document.getElementById('header-title');
  currentModel = 'models/gemini-flash-latest';

  // 高さ自動調整
  messageInput.addEventListener('input', function () {
    this.style.height = 'auto';
    this.style.height = this.scrollHeight + 'px';
  });
  // Enterで送信 / Shift+Enterで改行
  messageInput.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });

  // 送信ボタン
  document.getElementById('send-button').addEventListener('click', sendMessage);

  // モデル選択
  document.querySelectorAll('#model-menu .dropdown-item[data-value]').forEach((item) => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      currentModel = item.dataset.value;
      document.getElementById('selected-model-text').textContent = item.textContent.replace(/\(.*\)/, '').trim();
    });
  });

  // サイドバー開閉
  document.getElementById('sidebar-toggle-btn').addEventListener('click', () => {
    document.getElementById('sidebar').classList.toggle('collapsed');
  });

  // 新規チャット
  document.getElementById('new-chat-btn').addEventListener('click', startNewChat);

  // 会話リストのイベント委任（ピン/削除）
  const list = document.getElementById('conversation-list');
  list.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    e.preventDefault();
    e.stopPropagation();
    const action = btn.getAttribute('data-action');
    const convoId = btn.getAttribute('data-convo-id');
    if (action === 'pin') togglePin(convoId);
    if (action === 'delete') deleteConversation(convoId);
  });

  // 初回メッセージ読み込み
  loadMessages();
});
